# CMake generated Testfile for 
# Source directory: /home/anynomous/ZKP-Paillier-SP24-GPU2
# Build directory: /home/anynomous/ZKP-Paillier-SP24-GPU2/build-rtx2080ti
# 
# This file includes the relevant testing commands required for 
# testing this directory and lists subdirectories to be tested as well.
add_test("cpu_correctness" "/home/anynomous/ZKP-Paillier-SP24-GPU2/build-rtx2080ti/acceleration_tests")
set_tests_properties("cpu_correctness" PROPERTIES  _BACKTRACE_TRIPLES "/home/anynomous/ZKP-Paillier-SP24-GPU2/CMakeLists.txt;72;add_test;/home/anynomous/ZKP-Paillier-SP24-GPU2/CMakeLists.txt;0;")
add_test("cuda_correctness" "/home/anynomous/ZKP-Paillier-SP24-GPU2/build-rtx2080ti/acceleration_tests" "--cuda")
set_tests_properties("cuda_correctness" PROPERTIES  LABELS "gpu" SKIP_RETURN_CODE "77" _BACKTRACE_TRIPLES "/home/anynomous/ZKP-Paillier-SP24-GPU2/CMakeLists.txt;73;add_test;/home/anynomous/ZKP-Paillier-SP24-GPU2/CMakeLists.txt;0;")
add_test("cpu_protocol_smoke" "/home/anynomous/ZKP-Paillier-SP24-GPU2/build-rtx2080ti/zkp_bench" "--backend" "cpu" "--bits" "64" "--messages" "3" "--range-proofs" "3" "--threads" "2" "--repeat" "1")
set_tests_properties("cpu_protocol_smoke" PROPERTIES  TIMEOUT "120" _BACKTRACE_TRIPLES "/home/anynomous/ZKP-Paillier-SP24-GPU2/CMakeLists.txt;75;add_test;/home/anynomous/ZKP-Paillier-SP24-GPU2/CMakeLists.txt;0;")
add_test("gpu_acceptance_guards" "/usr/bin/python3.8" "/home/anynomous/ZKP-Paillier-SP24-GPU2/tests/test_gpu_acceptance.py")
set_tests_properties("gpu_acceptance_guards" PROPERTIES  _BACKTRACE_TRIPLES "/home/anynomous/ZKP-Paillier-SP24-GPU2/CMakeLists.txt;80;add_test;/home/anynomous/ZKP-Paillier-SP24-GPU2/CMakeLists.txt;0;")
