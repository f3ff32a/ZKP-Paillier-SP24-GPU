file(REMOVE_RECURSE
  "CMakeFiles/zkp_device_info.dir/link.d"
  "CMakeFiles/zkp_device_info.dir/tools/device_info.cu.o"
  "CMakeFiles/zkp_device_info.dir/tools/device_info.cu.o.d"
  "zkp_device_info"
  "zkp_device_info.pdb"
)

# Per-language clean rules from dependency scanning.
foreach(lang CUDA)
  include(CMakeFiles/zkp_device_info.dir/cmake_clean_${lang}.cmake OPTIONAL)
endforeach()
