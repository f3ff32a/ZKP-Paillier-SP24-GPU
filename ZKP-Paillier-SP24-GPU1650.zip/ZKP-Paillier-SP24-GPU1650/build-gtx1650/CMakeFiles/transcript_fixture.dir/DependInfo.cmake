
# Consider dependencies only in project.
set(CMAKE_DEPENDS_IN_PROJECT_ONLY OFF)

# The set of languages for which implicit dependencies are needed:
set(CMAKE_DEPENDS_LANGUAGES
  )

# The set of dependency files which are needed:
set(CMAKE_DEPENDS_DEPENDENCY_FILES
  "/home/szw/ZKP-Paillier-SP24-GPU1650/tests/v6_transcript_fixture.cpp" "CMakeFiles/transcript_fixture.dir/tests/v6_transcript_fixture.cpp.o" "gcc" "CMakeFiles/transcript_fixture.dir/tests/v6_transcript_fixture.cpp.o.d"
  "" "transcript_fixture" "gcc" "CMakeFiles/transcript_fixture.dir/link.d"
  )

# Targets to which this target links which contain Fortran sources.
set(CMAKE_Fortran_TARGET_LINKED_INFO_FILES
  )

# Targets to which this target links which contain Fortran sources.
set(CMAKE_Fortran_TARGET_FORWARD_LINKED_INFO_FILES
  )

# Fortran module output directory.
set(CMAKE_Fortran_TARGET_MODULE_DIR "")
