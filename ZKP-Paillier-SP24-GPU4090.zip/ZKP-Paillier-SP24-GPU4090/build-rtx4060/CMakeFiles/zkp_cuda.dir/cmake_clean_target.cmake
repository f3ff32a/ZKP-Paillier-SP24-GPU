file(REMOVE_RECURSE
  "libzkp_cuda.a"
)
