file(REMOVE_RECURSE
  "CMakeFiles/zkp_cuda.dir/src/cpp/app/acceleration/CudaBackend.cu.o"
  "CMakeFiles/zkp_cuda.dir/src/cpp/app/acceleration/CudaBackend.cu.o.d"
  "libzkp_cuda.a"
  "libzkp_cuda.pdb"
)

# Per-language clean rules from dependency scanning.
foreach(lang CUDA)
  include(CMakeFiles/zkp_cuda.dir/cmake_clean_${lang}.cmake OPTIONAL)
endforeach()
