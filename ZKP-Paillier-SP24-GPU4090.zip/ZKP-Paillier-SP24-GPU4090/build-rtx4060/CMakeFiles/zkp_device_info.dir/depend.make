# Empty dependencies file for zkp_device_info.
# This may be replaced when dependencies are built.
