file(REMOVE_RECURSE
  "libzkp_paillier.a"
)
