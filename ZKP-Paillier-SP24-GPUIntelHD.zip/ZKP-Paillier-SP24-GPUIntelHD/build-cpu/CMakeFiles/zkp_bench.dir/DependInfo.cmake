
# Consider dependencies only in project.
set(CMAKE_DEPENDS_IN_PROJECT_ONLY OFF)

# The set of languages for which implicit dependencies are needed:
set(CMAKE_DEPENDS_LANGUAGES
  )

# The set of dependency files which are needed:
set(CMAKE_DEPENDS_DEPENDENCY_FILES
  "/home/szw/ZKP-Paillier-SP24-GPUIntelHD/tools/benchmark.cpp" "CMakeFiles/zkp_bench.dir/tools/benchmark.cpp.o" "gcc" "CMakeFiles/zkp_bench.dir/tools/benchmark.cpp.o.d"
  "" "zkp_bench" "gcc" "CMakeFiles/zkp_bench.dir/link.d"
  )

# Targets to which this target links which contain Fortran sources.
set(CMAKE_Fortran_TARGET_LINKED_INFO_FILES
  )

# Targets to which this target links which contain Fortran sources.
set(CMAKE_Fortran_TARGET_FORWARD_LINKED_INFO_FILES
  )

# Fortran module output directory.
set(CMAKE_Fortran_TARGET_MODULE_DIR "")
