file(REMOVE_RECURSE
  "CMakeFiles/zkp_bench.dir/link.d"
  "CMakeFiles/zkp_bench.dir/tools/benchmark.cpp.o"
  "CMakeFiles/zkp_bench.dir/tools/benchmark.cpp.o.d"
  "zkp_bench"
  "zkp_bench.pdb"
)

# Per-language clean rules from dependency scanning.
foreach(lang CXX)
  include(CMakeFiles/zkp_bench.dir/cmake_clean_${lang}.cmake OPTIONAL)
endforeach()
