# Empty dependencies file for transcript_fixture.
# This may be replaced when dependencies are built.
