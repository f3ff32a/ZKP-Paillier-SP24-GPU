file(REMOVE_RECURSE
  "CMakeFiles/transcript_fixture.dir/link.d"
  "CMakeFiles/transcript_fixture.dir/tests/v6_transcript_fixture.cpp.o"
  "CMakeFiles/transcript_fixture.dir/tests/v6_transcript_fixture.cpp.o.d"
  "transcript_fixture"
  "transcript_fixture.pdb"
)

# Per-language clean rules from dependency scanning.
foreach(lang CXX)
  include(CMakeFiles/transcript_fixture.dir/cmake_clean_${lang}.cmake OPTIONAL)
endforeach()
