file(REMOVE_RECURSE
  "CMakeFiles/acceleration_tests.dir/link.d"
  "CMakeFiles/acceleration_tests.dir/tests/acceleration_tests.cpp.o"
  "CMakeFiles/acceleration_tests.dir/tests/acceleration_tests.cpp.o.d"
  "acceleration_tests"
  "acceleration_tests.pdb"
)

# Per-language clean rules from dependency scanning.
foreach(lang CXX)
  include(CMakeFiles/acceleration_tests.dir/cmake_clean_${lang}.cmake OPTIONAL)
endforeach()
